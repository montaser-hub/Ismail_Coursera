/*
Author:Montaser Ismail
Project Details:This is simple application that performs statistical analytics on a dataset. 
*/

